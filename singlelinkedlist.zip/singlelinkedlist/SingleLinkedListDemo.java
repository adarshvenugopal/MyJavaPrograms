package singlelinkedlist;

/**
 *
 * @author Adarsh
 */
public class SingleLinkedListDemo {
    public static void main(String...args){
        
        SingleLinkedList list = new SingleLinkedList();
        //call display with empty list
        list.display();
        //call deleteAfterValue with empty list
        list.deleteAfterValue(1);
        //call deleteAtEnd with empty list
        list.deleteAtEnd();
        //call deleteAtPosition with empty list
        list.deleteAtPosition(3);
        //call deleteAtStart with empty list
        list.deleteAtStart();
        //call getSize with empty list
        System.out.println("Size: " + list.getSize());
        
        //insert elements into the list at the end
        list.insertAtEnd(1);
        list.insertAtEnd(2);
        list.insertAtEnd(3);
        list.insertAtEnd(4);
        list.insertAtEnd(5);
        list.insertAtEnd(6);
        list.insertAtEnd(7);
        list.insertAtEnd(8);
        list.insertAtEnd(9);
        list.insertAtEnd(10);
        
        //call getSize with non-empty list
        System.out.println("Size: " + list.getSize()); 
        
        //call display with non-empty list
        list.display();
        
        //insert 0 in the beginning
        list.insertAtStart(0);
        
        //call display with non-empty list
        list.display();
        
        //insert 11 in the end
        list.insertAtEnd(11);
        
        //call display with non-empty list
        list.display();
        
        //delete at start
        list.deleteAtStart();
        
        //call display with non-empty list
        list.display(); 
        
        //insert 66 at position 6
        list.insertAtPosition(66, 6);
        
        //call display with non-empty list
        list.display();   
        
        //insert 33 after 3
        list.insertAfterValue(3, 33);
        
        //call display with non-empty list
        list.display();  
        
        //reverse the list
        list.reverseList();
        
        //call display with non-empty list
        list.display();
        
        //find Middle Element in the list
        
        Node mid = list.findMidElement();
        
        System.out.println("Middle element in the list is: " + mid.getData());
    }
}
