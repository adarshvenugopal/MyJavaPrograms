package singlelinkedlist;

import java.util.Scanner;

/**
 *
 * @author Adarsh
 */
public class NthElementFromEndOfLinkedList {
    public static void main(String...args){
        SingleLinkedList list1 = new SingleLinkedList();
        list1.insertAtEnd(2);
        list1.insertAtEnd(6);
        list1.insertAtEnd(3);
        list1.insertAtEnd(9);
        list1.insertAtEnd(7); 
        
        list1.display();
        
        Scanner input = new Scanner(System.in);
        System.out.print("Enter N: ");
        int n = input.nextInt();
        
        Node slow = list1.getStart();
        Node fast = slow;
        if(fast!=null){
            for(int i=1;i<=n-1 && fast.getNext()!=null;i++){
               fast = fast.getNext();
            }
            
            while(fast.getNext()!=null){
                slow = slow.getNext();
                fast = fast.getNext();
            }
            System.out.print("\nNth element from end of linked list is " + slow.getData() + "\n");
        }
        else{
            System.out.print("\nEmpty Linked List!\n");
        }
    }    
}
