package singlelinkedlist;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author Adarsh
 */
public class IntersectionOf2LinkedLists {

    public static void main(String...args){
        
        SingleLinkedList list1 = new SingleLinkedList();
        list1.insertAtEnd(2);
        list1.insertAtEnd(6);
        list1.insertAtEnd(3);
        list1.insertAtEnd(9);
        list1.insertAtEnd(7); 
        
        Node p = list1.getStart();
        while(p.getData() != 9){
            p = p.getNext();
        }
        
        Node q = p;
        
        SingleLinkedList list2 = new SingleLinkedList();
        list2.insertAtEnd(1);
        list2.insertAtEnd(4);
        
        p = list2.getStart();
        while(p.getNext() != null){
            p = p.getNext();
        }
        p.setNext(q);
        
        System.out.println("List 1:");
        list1.display();
        System.out.println("List 2:");
        list2.display();
        
        Map<Integer,Node> hashMap = new HashMap();
        p = list1.getStart();
        while(p != null){
           hashMap.put(p.hashCode(), p);
           p = p.getNext();
        }
        
        p = list2.getStart();
        while(p != null){
           if(hashMap.get(p.hashCode()) == p){
               break;
           }
           p = p.getNext();
        }
        
        if(p == null){
            System.out.println("No Intersecting Node!");
        }
        else{
            System.out.println("First Intersecting Node has the Data: " + p.getData());
        }
    }    
}
