package singlelinkedlist;

/**
 *
 * @author Adarsh
 */
public class PalindromeCheckDemo {
    public static void main(String...args){
        System.out.println("Non-palindromic list...");
        SingleLinkedList list1 = new SingleLinkedList();
        list1.insertAtEnd(1);
        list1.insertAtEnd(2);
        list1.insertAtEnd(3);
        list1.insertAtEnd(4);
        list1.insertAtEnd(5);
        list1.display();
        System.out.println("Is this above list a palindrome list? " + list1.isPalindrome());
        System.out.println("----------------------------------------");
        System.out.println("Palindromic list...");
        SingleLinkedList list2 = new SingleLinkedList();
        list2.insertAtEnd(1);
        list2.insertAtEnd(2);
        list2.insertAtEnd(3);
        list2.insertAtEnd(2);
        list2.insertAtEnd(1);
        list2.display();
        System.out.println("Is this above list a palindrome list? " + list2.isPalindrome());        
        
        
    }
}
