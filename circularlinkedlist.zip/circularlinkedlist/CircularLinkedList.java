package circularlinkedlist;

/**
 *
 * @author Adarsh
 */
public class CircularLinkedList {

    private Node start;
    
    public CircularLinkedList(){
        start = null;
    }
    
    private Node getLast(){
        Node p = start;
       
        if(p == null)
            return p;
        do{
            p = p.getNext();
        }while(p.getNext()!=start);        
        return p;
    }
    
    public int getSize(){
        int size = 0;
        Node p = start;

        if(start == null)
            return size;        
        
        do{
            size++;
            p = p.getNext();
        }while(p!=start);
        return size;
    }
    
    public void display(){
        
        if(start == null){
            System.out.print("List Empty!");
            System.out.println();
            return;
        }
        
        Node p = start;
        
        do{
            if(p.getNext() == start)
                System.out.print(p.getData());
            else
                System.out.print(p.getData() + " -> ");
            p = p.getNext();
        }while(p!=start);
        System.out.println();
    }
    
    public void insertAtEnd(int data){
        
        Node newNode = new Node(data); 
        
        if(start == null){
            start = newNode;
            newNode.setNext(start);
        }
        else{
            Node p = start;
            do{
                p = p.getNext();
            }while(p.getNext() != start);
            p.setNext(newNode);
            newNode.setNext(start);
        }
    }
    
    public void deleteAtEnd(){
       
        if(start == null){
            System.out.print("List empty!");
        }
        else{
            Node p = start;
            do{
                p = p.getNext();
            }while(p.getNext().getNext() != start);
            p.setNext(start);
        }
        System.out.println();
    }    
    
    public void insertAtStart(int data){
        
        Node newNode = new Node(data);
        
        if(start == null){
            start = newNode;
            newNode.setNext(start);
        }
        else{
            newNode.setNext(start);
            Node last = getLast();
            last.setNext(newNode);
            start = newNode;
            
        }
    }
    
    public void deleteAtStart(){
        
        if(start == null){
            System.out.print("List empty!");
        }
        else{
            Node last = getLast();
            last.setNext(start.getNext()); 
            start = start.getNext();
        }
        System.out.println();
    }    
    
    public void insertAtPosition(int data, int pos){
        
        int size = getSize();
        
        if(pos == 1){
           insertAtStart(data); 
        }
        else if(pos == (size+1)){
           insertAtEnd(data);
        }
        else if(pos > (size+1)){
           System.out.print("Invalid Position or List empty!");
        }
        else{
           Node newNode = new Node(data);
           Node p = start;
           
           for(int x=1;x!=(pos-1);x++)
               p = p.getNext();
           newNode.setNext(p.getNext());
           p.setNext(newNode);
        }
        System.out.println();
    }
    
    public void deleteAtPosition(int pos){
        
        int size = getSize();
        
        if(pos == 1){
           deleteAtStart(); 
        }
        else if(pos == size){
           deleteAtEnd();
        }
        else if(pos > size){
           System.out.print("Invalid Position or List empty!");
        }
        else{
           Node p = start;
           
           for(int x=1;x!=(pos-1);x++)
               p = p.getNext();
           p.setNext(p.getNext().getNext());
        }
        System.out.println();
    }    
    
    public void insertAfterValue(int data, int value){
        
        Node p = start;
        
        if(start == null)
            return;
        
        boolean flag = true;
        
        do{
            if(p.getData() == data)
                break;
            p = p.getNext();
            flag = false;
        }while(p!=start);
        
        if(p == start && !flag){
            System.out.printf("Value %d is not present in the list or the list is empty!", data);
        }
        else{
            Node newNode = new Node(value);
            newNode.setNext(p.getNext());
            p.setNext(newNode);
        }
        System.out.println();
    }
    
    public void deleteAfterValue(int value){
        
        Node p = start;

        if(start == null)
            return;
        
        boolean flag = true;
        
        do{
            if(p.getData() == value)
                break;
            p = p.getNext();
            flag = false;
        }while(p!=start);
        
        if(p == start && !flag){
            System.out.printf("Value %d is not present in the list or the list is empty!", value);
        }
        else{
            Node last = getLast();
            last.setNext(p.getNext().getNext());
            p.setNext(p.getNext().getNext());
        }
        System.out.println();
    }

    public void reverseList(){
        
        Node temp = null;
        Node prev = null;
        Node curr = start;
        
        do{
            temp = curr.getNext();
            curr.setNext(prev);
            prev = curr;
            curr = temp;
        }while(curr!=start);
        start = prev;
        curr.setNext(start);
    }
    
    public Node findMidElement(){
        
        Node slow,fast;
        slow = fast = start;
        
        do{
            slow = slow.getNext();
            fast = fast.getNext().getNext();
        }while(fast!=start && fast.getNext()!=start);
        return slow;
    }    
    
}
