package binarysearchtree;

/**
 *
 * @author Adarsh
 */
public class BinarySearchTree {
    
    private Node root;
    
    public BinarySearchTree(){
        root = null;
    }
    
    public void insert(int data){
        root = insert(root,data);
    }
    
    private Node insert(Node node, int data){
        if(node == null){
            node = new Node(data);
        }
        else if(data <= node.getData()){
            node.setLeft(insert(node.getLeft(),data));
        }
        else{
            node.setRight(insert(node.getRight(),data));
        }
        return node;
    }
    
    public boolean search(int data){
        return search(root, data);
    }
    
    private boolean search(Node node, int data){
        if(node == null){
            return false;
        }
        else if(data == node.getData()){
            return true;
        }
        else if(data < node.getData()){
            return search(node.getLeft(), data);
        }
        else{
            return search(node.getRight(), data);
        }
    }
}
