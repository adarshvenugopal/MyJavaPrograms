package binarysearchtree;

/**
 *
 * @author Adarsh
 */
public class BinarySearchTree {
    
    private Node root;
    
    public BinarySearchTree(){
        root = null;
    }
    
    public void insert(int data){
        root = insert(root,data);
    }
    
    private Node insert(Node node, int data){
        if(node == null){
            node = new Node(data);
        }
        else if(data <= node.getData()){
            node.setLeft(insert(node.getLeft(),data));
        }
        else{
            node.setRight(insert(node.getRight(),data));
        }
        return node;
    }
    
    public boolean search(int data){
        return search(root, data);
    }
    
    private boolean search(Node node, int data){
        if(node == null){
            return false;
        }
        else if(data == node.getData()){
            return true;
        }
        else if(data < node.getData()){
            return search(node.getLeft(), data);
        }
        else{
            return search(node.getRight(), data);
        }
    }
    
    public int findMin(){
        Node curr = root;
        
        if(curr == null){
            System.out.println("Empty Tree!");
            return -1;
        }
        else if(curr.getLeft() == null){
            return curr.getData();
        }
        else{
            while(curr.getLeft() != null){
                curr = curr.getLeft();
            }
            return curr.getData();
        }
    }
    
    public int findMax(){
        Node curr = root;
        
        if(curr == null){
            System.out.println("Empty Tree!");
            return -1;
        }
        else if(curr.getRight() == null){
            return curr.getData();
        }
        else{
            while(curr.getRight() != null){
                curr = curr.getRight();
            }
            return curr.getData();
        }
    }
    
    public int getHeight(){
        return getHeight(root);
    }
    
    private int getHeight(Node node){
        if(node == null)
            return -1;
        else
            return Math.max(getHeight(node.getLeft()),getHeight(node.getRight())) + 1;
    }
    
    public int getNoOfNodes(){
        return getNoOfNodes(root);
    }
    
    private int getNoOfNodes(Node node){
        if(node == null)
            return 0;
        else
            return getNoOfNodes(node.getLeft()) + getNoOfNodes(node.getRight()) + 1;
    }  
    
    public int getNoOfLeafNodes(){
        return getNoOfLeafNodes(root);
    }
    
    private int getNoOfLeafNodes(Node node){
        if(node == null)
            return 0;
        else if(node.getLeft() == null && node.getRight() == null)
            return 1;
        else
            return getNoOfLeafNodes(node.getLeft()) + getNoOfLeafNodes(node.getRight());
    } 
    
    
}
