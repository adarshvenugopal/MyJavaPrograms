package binarysearchtree;

/**
 *
 * @author Adarsh
 */
public class BinarySearchTreeDemo {
    public static void main(String...args){
        BinarySearchTree bst = new BinarySearchTree();
        
        bst.insert(10);
        bst.insert(5);
        bst.insert(50);
        bst.insert(33);
        bst.insert(25);
        bst.insert(8);
        bst.insert(2);
        bst.insert(19);
        
        System.out.printf("Is 2 is present in the tree? %s%n" , bst.search(2)? "Yes" : "No");
        System.out.printf("Is 19 is present in the tree? %s%n" , bst.search(19)? "Yes" : "No");
        System.out.printf("Is 29 is present in the tree? %s%n" , bst.search(29)? "Yes" : "No");
        
        System.out.printf("Minimum element in the tree is %d%n" , bst.findMin());
        System.out.printf("Maximum element in the tree is %d%n" , bst.findMax());
        
        System.out.printf("Height of the tree is %d%n" , bst.getHeight());
        System.out.printf("No of nodes in the tree is %d%n" , bst.getNoOfNodes());
        System.out.printf("No of leaf nodes in the tree is %d%n" , bst.getNoOfLeafNodes());
        
        System.out.println("Level order traversal of the tree:");
        bst.levelOrder();
        System.out.println();
        
        System.out.println("Pre order traversal of the tree:");
        bst.preOrder();
        System.out.println();  
        
        System.out.println("In order traversal of the tree:");
        bst.inOrder();
        System.out.println();   
        
        System.out.println("Post order traversal of the tree:");
        bst.postOrder();
        System.out.println();         
    }
}
