package binarysearchtree;

/**
 *
 * @author Adarsh
 */
public class BinarySearchTreeDemo {
    public static void main(String...args){
        BinarySearchTree bst = new BinarySearchTree();
        
        bst.insert(10);
        bst.insert(5);
        bst.insert(50);
        bst.insert(33);
        bst.insert(25);
        bst.insert(8);
        bst.insert(2);
        bst.insert(19);
        
        System.out.printf("Is 2 is present in the tree? %s%n" , bst.search(2)? "Yes" : "No");
        System.out.printf("Is 19 is present in the tree? %s%n" , bst.search(19)? "Yes" : "No");
        System.out.printf("Is 29 is present in the tree? %s%n" , bst.search(29)? "Yes" : "No");
        
    }
}
