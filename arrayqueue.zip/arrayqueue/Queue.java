package arrayqueue;

/**
 *
 * @author Adarsh
 */
public class Queue {
    
    private final int[] queuearray;
    private int front;
    private int rear;
    private static final int SIZE = 10;
    
    public Queue(){
       front = rear = -1; 
       queuearray = new int[SIZE];
    }
    
    public void enqueue(int element) throws QueueFullException{
        if(rear == SIZE-1)
            throw new QueueFullException();
        else
            queuearray[++rear] = element;
    }
    
    public int dequeue() throws QueueEmptyException{
        if(front == rear)
            throw new QueueEmptyException();
        else
            return queuearray[++front];
    }
    
    public int getSize(){
        return rear-front;
    }
}
