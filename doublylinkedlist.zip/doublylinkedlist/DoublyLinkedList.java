package doublylinkedlist;

/**
 *
 * @author Adarsh
 */
public class DoublyLinkedList {

    private Node start;
    
    public DoublyLinkedList(){
        start = null;
    }
    
    public int getSize(){
        int size = 0;
        Node p = start;
        
        while(p!=null){
            size++;
            p = p.getNext();
        }
        return size;
    }
    
    public void display(){
        
        if(start == null){
            System.out.print("List Empty!");
        }
        
        Node p = start;
        
        while(p!=null){
            if(p.getNext() == null)
                System.out.print(p.getData());
            else
                System.out.print(p.getData() + " -> ");
            p = p.getNext();
        }
        System.out.println();
    }
    
    public void insertAtEnd(int data){
        
        Node newNode = new Node(data); 
        
        if(start == null){
            start = newNode;
        }
        else{
            Node p = start;
            while(p.getNext() != null){
                p = p.getNext();
            }
            p.setNext(newNode);
            newNode.setPrev(p);
        }
    }
    
    public void deleteAtEnd(){
       
        if(start == null){
            System.out.print("List empty!");
        }
        else{
            Node p = start;
            while(p.getNext().getNext() != null){
                p = p.getNext();
            }
            p.getNext().setPrev(null);
            p.setNext(null);
        }
        System.out.println();
    }    
    
    public void insertAtStart(int data){
        
        Node newNode = new Node(data);
        
        if(start == null){
            start = newNode;
        }
        else{
            newNode.setNext(start);
            start.setPrev(newNode);
            start = newNode;
        }
    }
    
    public void deleteAtStart(){
        
        if(start == null){
            System.out.print("List empty!");
        }
        else{
            start.getNext().setPrev(null);
            Node temp = start.getNext();
            start.setNext(null);
            start = temp;
        }
        System.out.println();
    }    
    
    public void insertAtPosition(int data, int pos){
        
        int size = getSize();
        
        if(pos == 1){
           insertAtStart(data); 
        }
        else if(pos == (size+1)){
           insertAtEnd(data);
        }
        else if(pos > (size+1)){
           System.out.print("Invalid Position or List empty!");
        }
        else{
           Node newNode = new Node(data);
           Node p = start;
           
           for(int x=1;x!=(pos-1);x++)
               p = p.getNext();
           newNode.setNext(p.getNext());
           newNode.setPrev(p);
           p.getNext().setPrev(newNode);
           p.setNext(newNode);
        }
        System.out.println();
    }
    
    public void deleteAtPosition(int pos){
        
        int size = getSize();
        
        if(pos == 1){
           deleteAtStart(); 
        }
        else if(pos == size){
           deleteAtEnd();
        }
        else if(pos > size){
           System.out.print("Invalid Position or List empty!");
        }
        else{
           Node p = start;
           
           for(int x=1;x!=(pos-1);x++)
               p = p.getNext();
           p.getNext().getNext().setPrev(p);
           p.setNext(p.getNext().getNext());
        }
        System.out.println();
    }    
    
    public void insertAfterValue(int data, int value){
        
        Node p = start;
        
        while(p!=null){
            if(p.getData() == data)
                break;
            p = p.getNext();
        }
        
        if(p == null){
            System.out.printf("Value %d is not present in the list or the list is empty!", data);
        }
        else{
            Node newNode = new Node(value);
            newNode.setNext(p.getNext());
            newNode.setPrev(p);
            p.getNext().setPrev(newNode);
            p.setNext(newNode);            
        }
        System.out.println();
    }
    
    public void deleteAfterValue(int value){
        
        Node p = start;
        
        while(p!=null){
            if(p.getData() == value)
                break;
            p = p.getNext();
        }
        
        if(p == null){
            System.out.printf("Value %d is not present in the list or the list is empty!", value);
        }
        else{
           p.getNext().getNext().setPrev(p);
           p.setNext(p.getNext().getNext());
        }
        System.out.println();
    }

    public void reverseList(){
        
        Node temp = null;
        Node prev = null;
        Node curr = start;
        
        while(curr!=null){
            temp = curr.getNext();
            curr.setPrev(curr.getNext());
            curr.setNext(prev);
            prev = curr;
            curr = temp;
        }
        start = prev;
    }
    
    public Node findMidElement(){
        
        Node slow,fast;
        slow = fast = start;
        
        while(fast!=null && fast.getNext()!=null){
            slow = slow.getNext();
            fast = fast.getNext().getNext();
        }
        return slow;
    }
    
}
