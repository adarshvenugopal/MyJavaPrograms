package linkedlistqueue;

/**
 *
 * @author Adarsh
 */
public class QueueFullException extends Exception{

    @Override
    public String getMessage() {
        return "Queue is Full!";
    }
}
