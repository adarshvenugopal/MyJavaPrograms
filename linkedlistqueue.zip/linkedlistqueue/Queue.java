package linkedlistqueue;

/**
 *
 * @author Adarsh
 */
public class Queue {
    
    private Node front;
    private Node rear;
    
    public Queue(){
        front = null;
        rear = null;
    }
    
    public void enqueue(int element) throws QueueFullException{
        Node p = new Node(element);
        if(p == null)
            throw new QueueFullException(); 
        else{
            if(rear == null){
                rear = p;
                front = p;
            }
            else{
                rear.setNext(p);
                rear = p;
            }
        }
            
    }
    
    public int dequeue() throws QueueEmptyException{
        if(front == null){
            rear = null;
            throw new QueueEmptyException();
        }
        else{
        int data = front.getData();
        front = front.getNext();
        return data;
        }
    }
    
    public int getSize(){
        Node f = front;
        int size = 0;
        while(f != null){
            size++;
            f = f.getNext();
        }
        return size;
    }
}
