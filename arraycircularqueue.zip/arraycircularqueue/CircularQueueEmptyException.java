package arraycircularqueue;

/**
 *
 * @author Adarsh
 */
public class CircularQueueEmptyException extends Exception{

    @Override
    public String getMessage() {
        return "Queue is Empty!";
    }    
}
