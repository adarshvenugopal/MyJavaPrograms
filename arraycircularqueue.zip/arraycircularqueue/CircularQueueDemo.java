package arraycircularqueue;

/**
 *
 * @author Adarsh
 */
public class CircularQueueDemo {

    public static void main(String... args) {
        CircularQueue queue = new CircularQueue();
        try {
            //initial size
            System.out.println("Size before enqueueing: " + queue.getSize());

            System.out.println("Enqueueing...");
            //push
            for (int i = 0; i < 12; i++) {
                queue.enqueue(i);
            };
        } catch (CircularQueueFullException ex) {
            System.out.println(ex.getMessage());
        }

        //get size
        System.out.println("Size after enqueueing: " + queue.getSize());

        try {
            //pop
            System.out.println("Dequeueing 5 elements...");
            for (int i = 0; i < 5; i++) {
                System.out.println(queue.dequeue());
            }
        } catch (CircularQueueEmptyException ex) {
            System.out.println(ex.getMessage());
        }

        //get size
        System.out.println("Size after dequeueing: " + queue.getSize());

        try {
            System.out.println("Enqueueing 3 elements...");
            //push
            for (int i = 0; i < 3; i++) {
                queue.enqueue(i);
            };
        } catch (CircularQueueFullException ex) {
            System.out.println(ex.getMessage());
        }

        try {
            //pop
            System.out.println("Dequeueing all the remaining elements...");
            for (int i = 0; i < 9; i++) {
                System.out.println(queue.dequeue());
            }
        } catch (CircularQueueEmptyException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
