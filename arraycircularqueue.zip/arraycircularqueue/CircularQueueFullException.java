package arraycircularqueue;

/**
 *
 * @author Adarsh
 */
public class CircularQueueFullException extends Exception{

    @Override
    public String getMessage() {
        return "Queue is Full!";
    }
}
