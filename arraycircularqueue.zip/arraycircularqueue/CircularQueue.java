package arraycircularqueue;

/**
 *
 * @author Adarsh
 */
public class CircularQueue {
    
    private final int[] queuearray;
    private int front;
    private int rear;
    private static final int SIZE = 11;
    
    public CircularQueue(){
       front = rear = 0; 
       queuearray = new int[SIZE];
    }
    
    public void enqueue(int element) throws CircularQueueFullException{
        if((rear+1)%SIZE == front)
            throw new CircularQueueFullException();
        else{
            rear = (rear+1)%SIZE;
            queuearray[rear] = element;
        }
    }
    
    public int dequeue() throws CircularQueueEmptyException{
        if(front == rear)
            throw new CircularQueueEmptyException();
        else{
            front = (front+1)%SIZE;
            return queuearray[front];
        }
    }
    
    public int getSize(){
        return rear-front;
    }
}
