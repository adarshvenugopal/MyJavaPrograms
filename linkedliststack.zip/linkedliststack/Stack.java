package linkedliststack;

/**
 *
 * @author Adarsh
 */
public class Stack {

    private SingleLinkedList stack;
    
    public Stack(){
       stack = new SingleLinkedList();
    }
    
    public void push(int element) throws StackFullException{
        stack.insertAtStart(element);
    }
    
    public int pop() throws StackEmptyException{
        int data = stack.deleteAtStart();
        return data;
    }
    
    public int getSize(){
        return stack.getSize();
    }
}
