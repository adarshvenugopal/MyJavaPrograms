package linkedliststack;

/**
 *
 * @author Adarsh
 */
public class StackDemo {
    
    public static void main(String...args){
        Stack stack = new Stack();
        try {
            //initial size
            System.out.println("Size before pushing: " + stack.getSize());
            
            System.out.println("Pushing...");
            //push
            for(int i = 0;i<11;i++){
            stack.push(i);
            };
        } catch (StackFullException ex) {
            System.out.println(ex.getMessage());
        }
        
        //get size
        System.out.println("Size after pushing: " + stack.getSize());
        
        try{
        //pop
        System.out.println("Popping...");
            for(int i = 0;i<12;i++){
            System.out.println(stack.pop());
            }
        }catch (StackEmptyException ex) {
            System.out.println(ex.getMessage());
        }
        
         //get size
        System.out.println("Size after popping: " + stack.getSize());
    }
}
