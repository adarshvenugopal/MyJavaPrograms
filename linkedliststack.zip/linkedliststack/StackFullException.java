package linkedliststack;

/**
 *
 * @author Adarsh
 */
public class StackFullException extends Exception{

    @Override
    public String getMessage() {
        return "Stack is Full!";
    }
}
