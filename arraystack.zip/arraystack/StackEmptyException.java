package arraystack;

/**
 *
 * @author Adarsh
 */
public class StackEmptyException extends Exception{

    @Override
    public String getMessage() {
        return "Stack is Empty!";
    }    
}
