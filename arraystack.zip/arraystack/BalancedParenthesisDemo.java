package arraystack;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Adarsh
 */
public class BalancedParenthesisDemo {
    public static void main(String...args){
        Map<Character, Integer> map = new HashMap<>();
        map.put('{', 0);
        map.put('[', 1);
        map.put('(', 2);
        String properExpression = "{[(2 + 3) * (9 -2)] / (6 % 3)}";
        String improperExpression = "{[(2 + 3) * (9 -2 ] )";
        Stack stack = new Stack();
        
        for(char c : properExpression.toCharArray()){
            try {
                if(c == '{' || c == '[' || c == '(')
                    stack.push(map.get(c));
                if(c == '}' || c == ']' || c == ')')            
                    stack.pop();
            } catch (StackEmptyException | StackFullException ex) {
                System.out.println(ex.getMessage());
            }
        }

        System.out.printf("%s is %s proper expression%n", properExpression, stack.getSize() == 0 ? "a":"not a");
        
        for(char c : improperExpression.toCharArray()){
            try {
                if(c == '{' || c == '[' || c == '(')
                    stack.push(map.get(c));
                if(c == '}' || c == ']' || c == ')')            
                    stack.pop();
            } catch (StackEmptyException | StackFullException ex) {
                System.out.println(ex.getMessage());
            }
        }
        
        System.out.printf("%s is %s proper expression%n", improperExpression, stack.getSize() == 0 ? "a":"not a");       
        
    }
}
