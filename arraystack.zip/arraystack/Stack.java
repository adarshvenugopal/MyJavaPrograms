package arraystack;

/**
 *
 * @author Adarsh
 */
public class Stack {
    
    private final int[] stackarray;
    private int top;
    private static final int SIZE = 10;
    
    public Stack(){
       top = -1; 
       stackarray = new int[SIZE];
    }
    
    public void push(int element) throws StackFullException{
        if(top == SIZE-1)
            throw new StackFullException();
        else
            stackarray[++top] = element;
    }
    
    public int pop() throws StackEmptyException{
        if(top == -1)
            throw new StackEmptyException();
        else
            return stackarray[top--];
    }
    
    public int getSize(){
        return top+1;
    }
}
