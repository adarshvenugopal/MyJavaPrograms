package stackqueue;

/**
 *
 * @author Adarsh
 */
public class ReverseQueueUsingStackDemo {
    public static void main(String...args){
        System.out.println("\nNew Queue");
        
        Queue newqueue = new Queue();
        try {
            //initial size
            System.out.println("Size before enqueueing: " + newqueue.getSize());
            
            System.out.println("Enqueueing...");
            for(int i = 0;i<10;i++){
            newqueue.enqueue(i);
            };
        } catch (QueueFullException ex) {
            System.out.println(ex.getMessage());
        }

        System.out.println("\nReverse New Queue Using a Stack");
        Stack stack = new Stack();
        try{
        System.out.println("Reversing the queue...");
            for(int i = 0;i<10;i++){
            stack.push(newqueue.dequeue());
            }
            for(int i = 0;i<10;i++){
            newqueue.enqueue(stack.pop());
            }            
        }catch (QueueEmptyException ex) {
            System.out.println(ex.getMessage());
        } catch (StackFullException ex) {
            System.out.println(ex.getMessage());
        } catch (QueueFullException ex) {
            System.out.println(ex.getMessage());
        } catch (StackEmptyException ex) {
            System.out.println(ex.getMessage());
        }

        try{
        //dequeue
        System.out.println("Dequeueing all elements...");
            for(int i = 0;i<11;i++){
            System.out.println(newqueue.dequeue());
            }
        }catch (QueueEmptyException ex) {
            System.out.println(ex.getMessage());
        }        
    }
}
