package stackqueue;

/**
 *
 * @author Adarsh
 */
public class QueueDemo {
    
    public static void main(String...args){
        Queue queue = new Queue();
        try {
            //initial size
            System.out.println("Size before enqueueing: " + queue.getSize());
            
            System.out.println("Enqueueing...");
            //enqueue
            for(int i = 0;i<11;i++){
            queue.enqueue(i);
            };
        } catch (QueueFullException ex) {
            System.out.println(ex.getMessage());
        }
        
        //get size
        System.out.println("Size after enqueueing: " + queue.getSize());
        
        try{
        //dequeue
        System.out.println("Dequeueing 5 elements...");
            for(int i = 0;i<5;i++){
            System.out.println(queue.dequeue());
            }
        }catch (QueueEmptyException ex) {
            System.out.println(ex.getMessage());
        }
        //initial size
        System.out.println("Size after dequeueing 5 elements: " + queue.getSize());        
        
        try {
            System.out.println("Enqueueing 5 elements...");
            //enqueue
            for(int i = 0;i<5;i++){
            queue.enqueue(i);
            };
        } catch (QueueFullException ex) {
            System.out.println(ex.getMessage());
        }        
        
        try{
        //dequeue
        System.out.println("Dequeueing all elements...");
            for(int i = 0;i<11;i++){
            System.out.println(queue.dequeue());
            }
        }catch (QueueEmptyException ex) {
            System.out.println(ex.getMessage());
        }
        
         //get size
        System.out.println("Size after dequeueing: " + queue.getSize());
    }
}
