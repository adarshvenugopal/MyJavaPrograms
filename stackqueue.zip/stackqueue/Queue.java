package stackqueue;

/**
 *
 * @author Adarsh
 */
public class Queue {
    
    private Stack s1;
    private Stack s2;
    
    public Queue(){
        s1 = new Stack();
        s2 = new Stack();
    }
    
    public void enqueue(int element) throws QueueFullException{
        try {
            s1.push(element);
        } catch (StackFullException ex) {
            throw new QueueFullException();
        }
    }
    
    public int dequeue() throws QueueEmptyException{
        try{
            if(s2.getSize() == 0){
                while(s1.getSize() != 0){
                    int x = s1.pop();
                    try {
                        s2.push(x);
                    } catch (StackFullException ex) {
                    }
                }
            }
            int data = s2.pop();
            return data; 
        } catch (StackEmptyException ex) {
            throw new QueueEmptyException();
        }
    }
    
    public int getSize(){
        return s1.getSize()+s2.getSize();
    }
    
}
