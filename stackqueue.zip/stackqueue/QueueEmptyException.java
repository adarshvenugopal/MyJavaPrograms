package stackqueue;

/**
 *
 * @author Adarsh
 */
public class QueueEmptyException extends Exception{

    @Override
    public String getMessage() {
        return "Queue is Empty!";
    }    
}
